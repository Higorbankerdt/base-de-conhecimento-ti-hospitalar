CREATE TABLE IF NOT EXISTS sgu_users (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  username varchar(48) UNIQUE NOT NULL CHECK (username ~ '^[a-z0-9][a-z0-9._-]{2,47}$'),
  display_name varchar(100) NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin','leitor')),
  active boolean NOT NULL DEFAULT true,
  must_change boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sgu_sessions (
  token_hash char(64) PRIMARY KEY,
  user_id bigint NOT NULL REFERENCES sgu_users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS sgu_sessions_expiry ON sgu_sessions(expires_at);

CREATE TABLE IF NOT EXISTS sgu_documents (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title varchar(180) NOT NULL,
  module varchar(120) NOT NULL DEFAULT '',
  description varchar(1500) NOT NULL DEFAULT '',
  external_url text,
  pdf bytea,
  created_by bigint NOT NULL REFERENCES sgu_users(id),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((pdf IS NULL) <> (external_url IS NULL)),
  CHECK (pdf IS NULL OR octet_length(pdf) <= 8388608)
);

CREATE TABLE IF NOT EXISTS sgu_applied_imports (
  name text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sgu_processes (
  code varchar(16) PRIMARY KEY,
  title varchar(180) NOT NULL,
  sector varchar(120) NOT NULL DEFAULT '',
  objective varchar(1500) NOT NULL DEFAULT '',
  next_codes jsonb NOT NULL DEFAULT '[]'
);

ALTER TABLE sgu_documents ADD COLUMN IF NOT EXISTS process_code varchar(16) REFERENCES sgu_processes(code);
