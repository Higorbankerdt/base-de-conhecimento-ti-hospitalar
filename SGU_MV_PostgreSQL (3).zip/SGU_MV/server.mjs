import express from 'express';
import rateLimit from 'express-rate-limit';
import pg from 'pg';
import { createHash, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const derive = promisify(scrypt);
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('Informe DATABASE_URL.');
const pool = new pg.Pool({ connectionString: databaseUrl });
const sql = (query, args) => pool.query(query, args);
const initialHash = (await readFile(new URL('./admin.hash', import.meta.url), 'utf8')).trim();
const bootstrap = await pool.connect();
try {
  await bootstrap.query('BEGIN');
  await bootstrap.query('SELECT pg_advisory_xact_lock(728432)');
  await bootstrap.query(await readFile(new URL('./schema.sql', import.meta.url), 'utf8'));
  await bootstrap.query(
    "INSERT INTO sgu_users(username,display_name,password_hash,role) VALUES ('admin','Administrador',$1,'admin') ON CONFLICT (username) DO NOTHING",
    [initialHash]);
  const seed = await bootstrap.query(
    "INSERT INTO sgu_applied_imports(name) VALUES ('mv-docs-2026-11-23') ON CONFLICT DO NOTHING RETURNING name");
  if (seed.rowCount) {
    const catalog = await readFile(new URL('./catalogo-mv.json', import.meta.url), 'utf8');
    await bootstrap.query(`
      INSERT INTO sgu_documents(title,module,description,external_url,created_by)
      SELECT item.title,item.module,item.description,item.url,owner.id
      FROM jsonb_to_recordset($1::jsonb) AS item(title text,module text,description text,url text)
      CROSS JOIN (SELECT id FROM sgu_users WHERE username='admin') AS owner
      WHERE NOT EXISTS (SELECT 1 FROM sgu_documents AS doc WHERE doc.external_url=item.url)
      ORDER BY item.title
    `,[catalog]);
  }
  const processes = await readFile(new URL('./processos-locais.json', import.meta.url), 'utf8');
  await bootstrap.query(`INSERT INTO sgu_processes(code,title,sector,objective,next_codes)
    SELECT code,title,sector,objective,next_codes
    FROM jsonb_to_recordset($1::jsonb) AS item(code text,title text,sector text,objective text,next_codes jsonb)
    ON CONFLICT (code) DO NOTHING`,[processes]);
  await bootstrap.query('COMMIT');
} catch (error) {
  await bootstrap.query('ROLLBACK');
  throw error;
} finally {
  bootstrap.release();
}
const app = express();
app.disable('x-powered-by');
const secure = process.env.SECURE_COOKIE === '1';
const cookie = { httpOnly:true, sameSite:'strict', secure, path:'/' };
const cookieName = secure ? '__Host-sgu' : 'sgu';
const lifetimeMs = 8 * 3600_000;
const digest = value => createHash('sha256').update(value).digest('hex');
const userFields = 'id, username, display_name, role, active, must_change';
const documentFields = 'id,title,module,description,external_url,pdf IS NOT NULL AS has_pdf,updated_at,process_code';
const bad = (res,message,status=400) => res.status(status).json({error:message});
function field(value, max) {
  return typeof value === 'string' && value.trim().length <= max ? value.trim() : '';
}
function password(value) {
  return typeof value==='string' && value.length>=6 && value.length<=128;
}
async function hashPassword(value) {
  const salt=randomBytes(16).toString('hex');
  return salt+':'+(await derive(value,salt,64)).toString('hex');
}
async function matches(value, stored) {
  const [salt,expected]=stored.split(':');
  return timingSafeEqual(await derive(value,salt,64),Buffer.from(expected,'hex'));
}
function token(request) {
  const match = (request.headers.cookie ?? '').split(';').map(x=>x.trim()).find(v=>v.startsWith(cookieName+'='));
  const value = match?.slice(cookieName.length+1);
  return /^[a-f0-9]{64}$/.test(value??'') ? digest(value) : '';
}
async function session(req,res,next) {
  req.sessionKey=token(req);
  if(!req.sessionKey) return bad(res,'Faça login.',401);
  const result=await sql(`SELECT u.${userFields.replaceAll(', ', ', u.')} FROM sgu_sessions s JOIN sgu_users u ON u.id=s.user_id
       WHERE token_hash=$1 AND expires_at>now() AND u.active`,[req.sessionKey]);
  req.user=result.rows[0];
  if(!req.user) return bad(res,'Sessão expirada. Faça login novamente.',401);
  next();
}
function ready(req,res,next) {
  if(req.user.must_change) return bad(res,'Altere a senha inicial.',403);
  next();
}
function admin(req,res,next) {
  if(req.user.role!=='admin') return bad(res,'Acesso restrito a administradores.',403);
  next();
}
app.use((req,res,next)=>{
  res.set({
    'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
    'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
  });
  if(req.path.startsWith('/api/')) res.set('Cache-Control','no-store');
  if(!['GET','HEAD','OPTIONS'].includes(req.method) &&
    (req.get('X-SGU-Request')!=='1' || req.get('Sec-Fetch-Site')==='cross-site')) {
    return bad(res,'Solicitação inválida.',403);
  }
  next();
});
app.use(express.json({limit:'12mb'}));
app.use('/api/login',rateLimit({windowMs:15*60_000,limit:12,
  handler:(_req,res)=>bad(res,'Muitas tentativas. Aguarde alguns minutos.',429)}));
app.post('/api/login',async(req,res)=>{
  const username=field(req.body?.username,48).toLowerCase();
  const value=req.body?.password;
  if(typeof value!=='string'||value.length>128) return bad(res,'Credenciais inválidas.',401);
  const user=(await sql(`SELECT ${userFields},password_hash FROM sgu_users WHERE username=$1`,[username])).rows[0];
  const valid=await matches(value,user?.password_hash??initialHash);
  if(!user?.active||!valid) return bad(res,'Credenciais inválidas.',401);
  await sql('DELETE FROM sgu_sessions WHERE expires_at<=now() OR token_hash=$1',[token(req)]);
  const raw=randomBytes(32).toString('hex');
  await sql("INSERT INTO sgu_sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval '8 hours')",[digest(raw),user.id]);
  delete user.password_hash;
  res.cookie(cookieName,raw,{...cookie,maxAge:lifetimeMs}).json(user);
});
app.get('/api/me',session,(req,res)=>res.json(req.user));
app.post('/api/logout',session,async(req,res)=>{
  await sql('DELETE FROM sgu_sessions WHERE token_hash=$1',[req.sessionKey]);
  res.clearCookie(cookieName,cookie).status(204).end();
});
app.post('/api/password',session,async(req,res)=>{
  const {current,newPassword}=req.body??{};
  if(!password(newPassword)||typeof current!=='string'||current.length>128||current===newPassword) {
    return bad(res,'Informe uma senha nova e diferente com 6 a 128 caracteres.');
  }
  const user=(await sql('SELECT password_hash FROM sgu_users WHERE id=$1',[req.user.id])).rows[0];
  if(!await matches(current,user.password_hash)) return bad(res,'Senha atual incorreta.',401);
  const result=await sql(`WITH changed AS (
    UPDATE sgu_users SET password_hash=$1,must_change=false WHERE id=$2 AND password_hash=$4 RETURNING id
  ), revoked AS (
    DELETE FROM sgu_sessions WHERE user_id IN (SELECT id FROM changed) AND token_hash<>$3
  ) SELECT id FROM changed`,[await hashPassword(newPassword),req.user.id,req.sessionKey,user.password_hash]);
  if(!result.rowCount) return bad(res,'A senha mudou. Atualize a sessão.',409);
  res.status(204).end();
});
app.get('/api/users',session,ready,admin,async(_req,res)=>{
  res.json((await sql(`SELECT ${userFields} FROM sgu_users ORDER BY username`)).rows);
});
app.post('/api/users',session,ready,admin,async(req,res)=>{
  const username=field(req.body?.username,48).toLowerCase();
  const name=field(req.body?.displayName,100);
  const {role,password:value}=req.body??{};
  if(!/^[a-z0-9][a-z0-9._-]{2,47}$/.test(username)||!name||!['admin','leitor'].includes(role)||!password(value)) {
    return bad(res,'Confira o nome de usuário, o perfil e a senha de 6 a 128 caracteres.');
  }
  const result=await sql(`INSERT INTO sgu_users(username,display_name,role,password_hash) VALUES($1,$2,$3,$4)
    ON CONFLICT (username) DO NOTHING RETURNING ${userFields}`,[username,name,role,await hashPassword(value)]);
  if(!result.rowCount) return bad(res,'Este usuário já existe.',409);
  res.status(201).json(result.rows[0]);
});
app.patch('/api/users/:id',session,ready,admin,async(req,res)=>{
  if(!/^[0-9]{1,18}$/.test(req.params.id)||typeof req.body?.active!=='boolean') return bad(res,'Dados inválidos.');
  if(req.params.id===req.user.id) return bad(res,'Sua conta atual deve permanecer ativa.',409);
  const result=await sql(`WITH changed AS (
    UPDATE sgu_users SET active=$1 WHERE id=$2 AND username<>'admin' RETURNING id
  ), revoked AS (
    DELETE FROM sgu_sessions WHERE user_id IN (SELECT id FROM changed) AND NOT $1
  ) SELECT id FROM changed`,[req.body.active,req.params.id]);
  if(!result.rowCount) return bad(res,'Usuário indisponível para alteração.',404);
  res.status(204).end();
});
app.get('/api/processes',session,ready,async(_req,res)=>{
  res.json((await sql(`SELECT p.*, (SELECT count(*)::int FROM sgu_documents d WHERE d.process_code=p.code) AS document_count
    FROM sgu_processes p ORDER BY p.code`)).rows);
});
app.put('/api/processes/:code',session,ready,admin,async(req,res)=>{
  const code=req.params.code;
  const title=field(req.body?.title,180);
  const sector=field(req.body?.sector,120);
  const objective=field(req.body?.objective,1500);
  if(!/^[A-Z0-9-]{2,16}$/.test(code)||!title) return bad(res,'Informe um código e um título válidos.');
  const next=req.body?.nextCodes;
  if(next!==undefined && (!Array.isArray(next)||next.length>30||next.some(value=>typeof value!=='string'||value===code||!/^[A-Z0-9-]{2,16}$/.test(value)))) {
    return bad(res,'Selecione processos de destino válidos.');
  }
  const unique=next===undefined?null:[...new Set(next)];
  if(unique?.length && (await sql('SELECT code FROM sgu_processes WHERE code=ANY($1::text[])',[unique])).rowCount!==unique.length) {
    return bad(res,'Um processo de destino não foi encontrado.');
  }
  const result=await sql(`INSERT INTO sgu_processes(code,title,sector,objective,next_codes)
    VALUES($1,$2,$3,$4,COALESCE($5::jsonb,'[]'))
    ON CONFLICT (code) DO UPDATE SET title=EXCLUDED.title,sector=EXCLUDED.sector,
      objective=EXCLUDED.objective,next_codes=COALESCE($5::jsonb,sgu_processes.next_codes) RETURNING *`,
    [code,title,sector,objective,unique===null?null:JSON.stringify(unique)]);
  res.json(result.rows[0]);
});
app.get('/api/documents',session,ready,async(req,res)=>{
  const search=field(req.query.q,180);
  const process=field(req.query.process,16);
  const scope=field(req.query.scope,10);
  const rows=await sql(`SELECT ${documentFields} FROM sgu_documents
    WHERE ($1='' OR strpos(lower(concat_ws(' ',title,module,description)),lower($1))>0)
    AND ($2='' OR process_code=$2)
    AND ($3<>'local' OR pdf IS NOT NULL OR process_code IS NOT NULL OR description NOT LIKE 'MV Docs · %')
    ORDER BY updated_at DESC,id DESC`,[search,process,scope]);
  res.json(rows.rows);
});
function documentData(body) {
  const title=field(body?.title,180);
  const module=field(body?.module,120);
  const description=field(body?.description,1500);
  const url=field(body?.url,2000);
  let pdf=null;
  if(!title) throw new TypeError('Informe o título.');
  if(url) {
    const address=URL.parse(url);
    if(!address||!['https:','http:'].includes(address.protocol)||address.username||address.password) {
      throw new TypeError('Informe uma URL HTTP ou HTTPS válida.');
    }
  }
  if(body?.pdf) {
    if(typeof body.pdf!=='string'||body.pdf.length>11_184_812) throw new TypeError('PDF excede 8 MB.');
    pdf=Buffer.from(body.pdf,'base64');
    if(pdf.length>8_388_608||pdf.subarray(0,5).toString()!=='%PDF-') throw new TypeError('Selecione um PDF válido de até 8 MB.');
  }
  if(url&&pdf) throw new TypeError('Escolha URL ou arquivo PDF.');
  return {title,module,description,url:url||null,pdf};
}
app.put('/api/documents/:id',session,ready,admin,async(req,res)=>{
  const id=req.params.id;
  if(id!=='novo'&&!/^[0-9]{1,18}$/.test(id)) return bad(res,'Documento inválido.');
  let data;
  try { data=documentData(req.body); } catch(error) { return bad(res,error.message); }
  const {title,module,description,url,pdf}=data;
  const hasProcess=Object.hasOwn(req.body,'processCode');
  const process=field(req.body?.processCode,16)||null;
  if(process && !(await sql('SELECT 1 FROM sgu_processes WHERE code=$1',[process])).rowCount) {
    return bad(res,'Processo não encontrado.');
  }
  if(id==='novo'&&!url&&!pdf) return bad(res,'Anexe um PDF ou informe uma URL.');
  const result=id==='novo'
    ? await sql(`INSERT INTO sgu_documents(title,module,description,external_url,pdf,created_by,process_code) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING ${documentFields}`,
      [title,module,description,url,pdf,req.user.id,process])
    : await sql(`UPDATE sgu_documents SET title=$1,module=$2,description=$3,
      external_url=CASE WHEN $5::bytea IS NOT NULL THEN NULL ELSE COALESCE($4,external_url) END,
      pdf=CASE WHEN $4::text IS NOT NULL THEN NULL ELSE COALESCE($5,pdf) END, process_code=CASE WHEN $7 THEN $8 ELSE process_code END,updated_at=now() WHERE id=$6 RETURNING ${documentFields}`,
      [title,module,description,url,pdf,id,hasProcess,process]);
  if(!result.rowCount) return bad(res,'Documento não encontrado.',404);
  res.status(id==='novo'?201:200).json(result.rows[0]);
});
app.get('/api/documents/:id/pdf',session,ready,async(req,res)=>{
  if(!/^[0-9]{1,18}$/.test(req.params.id)) return bad(res,'Documento inválido.');
  const pdf=(await sql('SELECT pdf FROM sgu_documents WHERE id=$1',[req.params.id])).rows[0]?.pdf;
  if(!pdf) return bad(res,'PDF não encontrado.',404);
  res.attachment('documento-'+req.params.id+'.pdf').type('application/pdf').send(pdf);
});
app.delete('/api/documents/:id',session,ready,admin,async(req,res)=>{
  if(!/^[0-9]{1,18}$/.test(req.params.id)) return bad(res,'Documento inválido.');
  const result=await sql('DELETE FROM sgu_documents WHERE id=$1',[req.params.id]);
  if(!result.rowCount) return bad(res,'Documento não encontrado.',404);
  res.status(204).end();
});
app.use('/api',(_req,res)=>bad(res,'Rota não encontrada.',404));
app.use(express.static(fileURLToPath(new URL('./public',import.meta.url))));
app.use((error,_req,res,_next)=>{
  if(error.status===400||error.status===413) return bad(res,error.status===413?'Envio acima do limite.':'Envio inválido.',error.status);
  console.error(error.code??error.name);
  return bad(res,'Ocorreu um erro no servidor.',500);
});
const server=app.listen(Number(process.env.PORT??8080),process.env.HOST??'0.0.0.0',()=>console.log('SGU disponível.'));
process.on('SIGTERM',()=>server.close(()=>pool.end()));
