const el=id=>document.getElementById(id);
const notice=el('notice'),documentDialog=el('document-dialog'),userDialog=el('user-dialog');
const processDialog=el('process-dialog');
let account=null, editing=null, activeView='overview', selectedProcess='';
let processes=[], displayedDocs=[], documentLimit=24;
async function api(path,method='GET',data) {
  const response=await fetch('/api'+path,{
    method,headers:{'Content-Type':'application/json','X-SGU-Request':'1'},
    body:data===undefined?undefined:JSON.stringify(data)
  });
  if(response.status===204) return;
  const result=await response.json();
  if(!response.ok) throw Object.assign(new Error(result.error),{status:response.status});
  return result;
}
function item(tag,value,cls) {
  const n=document.createElement(tag);
  if(value) n.textContent=value;
  if(cls) n.className=cls;
  return n;
}
function button(label,action) {
  const node=item('button',label,'secondary');
  node.type='button';
  node.addEventListener('click',()=>safe(action));
  return node;
}
async function safe(action,target=notice) {
  target.textContent='';
  try {await action();} catch(error) {target.textContent=error.message;}
}
function bind(id,action,target=notice) {
  const form=el(id);
  form.addEventListener('submit',async event=>{
    event.preventDefault();
    const submit=form.querySelector('button:not([type="button"])');
    submit.disabled=true;
    try {await safe(()=>action(Object.fromEntries(new FormData(form)),form),target);}
    finally {submit.disabled=false;}
  });
}
function readPdf(file) {
  if(file.size>8_388_608) throw new Error('O PDF deve ter até 8 MB.');
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(reader.result.split(',')[1]);
    reader.onerror=()=>reject(new Error('Não foi possível ler o PDF.'));
    reader.readAsDataURL(file);
  });
}
function showDocument(doc=null) {
  editing=doc?.id??null;
  const form=el('document-form');
  form.reset();
  form.querySelector('.form-error').textContent='';
  el('document-title').textContent=doc?'Editar documento':'Novo documento';
  for(const key of ['title','module','description']) form.elements[key].value=doc?.[key]??'';
  if(doc?.external_url) form.elements.url.value=doc.external_url;
  form.elements.processCode.value=doc ? doc.process_code??'' : el('document-process').value;
  form.querySelector('.hint').textContent=doc
    ?'Para manter o arquivo atual, deixe o campo de arquivo vazio. Para trocar o link por um PDF, limpe o link.'
    :'Informe um link ou selecione um PDF.';
  documentDialog.showModal();
}
async function documents() {
  const params=new URLSearchParams({
    q:el('query').value,process:el('document-process').value,scope:activeView==='repository'?'local':'all'
  });
  displayedDocs=await api('/documents?'+params);
  documentLimit=24;
  renderDocuments();
}
function renderDocuments() {
  const results=displayedDocs, container=el('documents');
  container.replaceChildren();
  el('document-count').textContent=results.length+' documento(s)';
  el('more-documents').hidden=results.length<=documentLimit;
  if(!results.length) container.append(item('p','Nenhum documento encontrado.'));
  for(const doc of results.slice(0,documentLimit)) {
    const row=item('article','','row'), content=item('div'),actions=item('div','','actions');
    const process=processes.find(p=>p.code===doc.process_code);
    content.append(item('p',[doc.module,process?.code].filter(Boolean).join(' · '),'badges'),item('h3',doc.title),item('p',doc.description));
    const link=item('a',doc.has_pdf?'Baixar PDF':'Abrir link','link-button');
    link.href=doc.has_pdf?'/api/documents/'+doc.id+'/pdf':doc.external_url;
    if(!doc.has_pdf) {link.target='_blank';link.rel='noopener noreferrer';}
    actions.append(link);
    if(account.role==='admin') actions.append(button('Editar',()=>showDocument(doc)),button('Excluir',async()=>{
      if(confirm('Excluir “'+doc.title+'” permanentemente?')) {
        await api('/documents/'+doc.id,'DELETE');
        await loadProcesses();
        await documents();
      }
    }));
    row.append(content,actions);
    container.append(row);
  }
}
async function users() {
  const list=await api('/users');
  const container=el('user-list');
  container.replaceChildren();
  for(const user of list) {
    const row=item('article','','row'),content=item('div');
    const role=user.role==='admin'?'Administrador':'Leitor';
    content.append(item('h3',user.display_name),item('p',[user.username,role,user.active?'Ativo':'Desativado'].join(' · ')));
    row.append(content);
    if(user.username!=='admin'&&user.id!==account.id) {
      row.append(button(user.active?'Desativar':'Reativar',async()=>{
        await api('/users/'+user.id,'PATCH',{active:!user.active});
        await users();
      }));
    }
    container.append(row);
  }
}
function openProcessForm(process=null) {
  const form=el('process-form');
  form.reset();
  form.querySelector('.form-error').textContent='';
  el('process-title').textContent=process?'Editar processo':'Novo processo';
  for(const key of ['code','title','sector','objective']) form.elements[key].value=process?.[key]??'';
  form.elements.code.readOnly=!!process;
  el('next-processes').replaceChildren(...processes.filter(p=>p.code!==process?.code).map(p=>
    new Option(p.code+' · '+p.title,p.code,false,process?.next_codes.includes(p.code)??false)));
  processDialog.showModal();
}
function renderProcesses(code) {
  selectedProcess=code;
  const grid=el('process-list'),detail=el('process-detail');
  grid.replaceChildren();
  for(const process of processes) {
    const control=button('',()=>{renderProcesses(process.code);el('process-detail').focus();});
    control.className='process-card';
    control.setAttribute('aria-pressed',String(process.code===code));
    control.append(item('small',process.code),item('strong',process.title),item('span',process.document_count+' documento(s)'));
    grid.append(control);
  }
  const process=processes.find(p=>p.code===code);
  detail.hidden=!process;
  if(!process)return;
  detail.tabIndex=-1;
  detail.replaceChildren(item('p',process.code,'badges'),item('h2',process.title),item('p',process.sector),item('p',process.objective));
  const actions=item('div','','tags');
  actions.append(button('Ver documentos vinculados',()=>setView('repository',{process:process.code})));
  if(account.role==='admin') actions.append(button('Editar processo',()=>openProcessForm(process)));
  detail.append(actions);
  const next=process.next_codes.map(code=>processes.find(p=>p.code===code)).filter(Boolean);
  if(next.length) {
    const links=item('div','','tags');
    links.append(...next.map(p=>button(p.code+' · '+p.title,()=>{renderProcesses(p.code);el('process-detail').focus();})));
    detail.append(item('h3','Próximos processos'),links);
  }
}
async function loadProcesses() {
  processes=await api('/processes');
  for(const [id,label] of [['document-process','Todos os processos'],['upload-process','Sem vínculo']]) {
    const select=el(id),saved=select.value;
    select.replaceChildren(new Option(label,''),...processes.map(p=>new Option(p.code+' · '+p.title,p.code)));
    if(processes.some(p=>p.code===saved))select.value=saved;
  }
  el('dashboard-processes').replaceChildren(...processes.slice(0,7).map(p=>button(p.code+' · '+p.title,()=>setView('processes',{process:p.code}))));
  el('count-processes').textContent=processes.length;
}
async function overview() {
  const [all,local]=await Promise.all([api('/documents'),api('/documents?scope=local')]);
  el('count-documents').textContent=all.length;
  el('count-local').textContent=local.length;
  const totals=new Map();
  for(const {module} of all) if(module) totals.set(module,(totals.get(module)??0)+1);
  const topics=[...totals].sort((a,b)=>b[1]-a[1]).slice(0,8);
  el('topics').replaceChildren(...topics.map(([title])=>button(title,()=>setView('knowledge',{query:title}))));
}
async function setView(view,{query='',process=''}={}) {
  activeView=view;
  for(const id of ['overview','document-section','processes','users']) el(id).hidden=true;
  for(const button of el('sections').querySelectorAll('button')) {
    if(button.dataset.view===view)button.setAttribute('aria-current','page');
    else button.removeAttribute('aria-current');
  }
  if(view==='knowledge'||view==='repository') {
    el('document-section').hidden=false;
    el('document-heading').textContent=view==='repository'?'Repositório de anexos locais':'Base de conhecimento';
    el('query').value=query;
    el('document-process').value=process;
    await documents();
  } else {
    el(view).hidden=false;
    if(view==='processes')renderProcesses(process||selectedProcess||processes[0]?.code);
    if(view==='overview')await overview();
    if(view==='users')await users();
  }
}
async function show(user) {
  account=user;
  const ready=user&&!user.must_change;
  const admin=ready&&user.role==='admin';
  el('login').hidden=!!user;
  el('password').hidden=!user?.must_change;
  el('logout').hidden=!user;
  el('dashboard').hidden=!ready;
  el('user-nav').hidden=!admin;
  el('new-document').hidden=!admin;
  el('quick-document').hidden=!admin;
  el('new-process').hidden=!admin;
  if(ready) {
    el('identity').textContent=user.display_name+' · '+(admin?'Administrador':'Leitor');
    await loadProcesses();
    await setView('overview');
  }
}
bind('login-form',async(data,form)=>{const user=await api('/login','POST',data);form.reset();await show(user);});
bind('password-form',async(data,form)=>{await api('/password','POST',data);form.reset();await show(await api('/me'));});
bind('search',documents);
bind('document-form',async(data)=>{
  const {file,...fields}=data;
  if(file?.size) fields.pdf=await readPdf(file);
  await api('/documents/'+(editing??'novo'),'PUT',fields);
  documentDialog.close();
  await loadProcesses();
  if(activeView==='overview') await overview();
  else if(activeView==='repository'||activeView==='knowledge') await documents();
},el('document-form').querySelector('.form-error'));
bind('user-form',async(data)=>{await api('/users','POST',data);userDialog.close();await users();},el('user-form').querySelector('.form-error'));
el('new-document').addEventListener('click',()=>showDocument());
el('new-user').addEventListener('click',()=>{const form=el('user-form');form.reset();form.querySelector('.form-error').textContent='';userDialog.showModal();});
el('logout').addEventListener('click',()=>safe(async()=>{await api('/logout','POST');await show(null);}));
bind('process-form',async data=>{
  const nextCodes=[...el('next-processes').selectedOptions].map(option=>option.value);
  await api('/processes/'+encodeURIComponent(data.code.trim().toUpperCase()),'PUT',{...data,nextCodes});
  processDialog.close();
  await loadProcesses();
  renderProcesses(data.code.trim().toUpperCase());
},el('process-form').querySelector('.form-error'));
document.querySelectorAll('[data-view]').forEach(control=>control.addEventListener('click',()=>safe(()=>setView(control.dataset.view))));
el('document-process').addEventListener('change',()=>safe(documents));
el('more-documents').addEventListener('click',()=>{documentLimit+=24;renderDocuments();});
el('new-process').addEventListener('click',()=>openProcessForm());
el('quick-document').addEventListener('click',()=>showDocument());
for(const dialog of [documentDialog,userDialog,processDialog]) dialog.querySelector('.cancel').addEventListener('click',()=>dialog.close());
await safe(async()=>{
  let user;
  try {user=await api('/me');} catch(error) {if(error.status!==401) throw error;}
  await show(user??null);
});
