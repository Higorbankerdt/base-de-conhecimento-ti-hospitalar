# TI Hospitalar ES

Sistema web para administrar contas e um catálogo interno de documentação, com persistência em PostgreSQL. Administradores gerenciam usuários e documentos. Leitores pesquisam documentos e acessam os arquivos.

## Iniciar

No Windows, abra o Docker Desktop e execute `Iniciar_SGU.cmd` na pasta extraída. O iniciador cria a configuração local, sobe os serviços e abre o navegador quando a tela de login responde.

Em outras plataformas, use Docker com Compose e Node.js.

```sh
node configurar.mjs
docker compose up -d --build
```

Abra http://localhost:8080. Entre como `admin` com a senha inicial informada no pedido. O primeiro acesso exige uma nova senha. O cadastro é criado somente quando ainda não existe uma conta `admin` e não redefine a senha em reinicializações.

A interface tem acesso à página Consulta MV. O cadastro interno aceita um link HTTP/HTTPS ou um PDF de até 8 MB. Os PDFs enviados ficam no PostgreSQL e são baixados apenas por usuários autenticados. Links externos continuam sujeitos às permissões de seus respectivos portais.

## Windows sem Docker

Instale o Node.js LTS (versão 22 ou superior) e execute `Iniciar_SGU_Sem_Docker.cmd` na pasta extraída. O iniciador instala as dependências do pacote, sobe o PostgreSQL 17 local e abre http://127.0.0.1:8080. Mantenha a janela do iniciador aberta durante o uso. O banco do modo sem Docker fica em `%LOCALAPPDATA%\SGU-MV` e persiste entre execuções.

O catálogo do MV Docs é importado automaticamente no primeiro início após esta atualização. Os documentos são registrados como links de origem. O PostgreSQL preserva anexos locais, registros existentes e contas. A busca por título, módulo ou descrição também inclui o catálogo. Senhas novas aceitam de 6 a 128 caracteres.

O painel reúne a base de conhecimento, o repositório de anexos e os processos interligados. Sete processos iniciais vêm do layout de referência. Administradores podem editar os processos, indicar seus próximos destinos e vincular documentos. O repositório mostra anexos, links cadastrados no SGU e documentos vinculados a processos.

## Banco

- `sgu_users` — identificação, perfil, senha com hash e status.
- `sgu_sessions` — sessões revogáveis com validade de oito horas.
- `sgu_documents` — título, módulo, descrição, arquivo PDF ou URL, autor e data da atualização.

A aplicação cria o esquema na primeira execução. O Compose mantém o banco em um volume persistente e vincula a interface à máquina local. Para usar um PostgreSQL existente, configure `DATABASE_URL`, rode `npm ci` e inicie com `node server.mjs`. Em ambiente HTTPS, configure `SECURE_COOKIE=1` e termine TLS no proxy.
