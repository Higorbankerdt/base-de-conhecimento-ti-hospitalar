import EmbeddedPostgres from 'embedded-postgres';
import { randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const isWindows = process.platform === 'win32';
const dataDir = process.env.SGU_DATA_DIR ??
  (isWindows && process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'SGU-MV') : '');
if (!dataDir) throw new Error('Informe SGU_DATA_DIR para executar neste sistema.');
mkdirSync(dataDir, {recursive:true});
const keyPath = join(dataDir, 'postgres.key');
try {
  writeFileSync(keyPath, randomBytes(32).toString('hex'), {flag:'wx',mode:0o600});
} catch (error) {
  if (error.code !== 'EEXIST') throw error;
}
const password = readFileSync(keyPath, 'utf8').trim();
if (!/^[a-f0-9]{64}$/.test(password)) throw new Error('Arquivo de configuração local inválido.');

const cluster = join(dataDir, 'postgres');
const port = 55432;
const database = new EmbeddedPostgres({
  databaseDir:cluster, user:'sgu', password, port, persistent:true, authMethod:'scram-sha-256',
  postgresFlags:['-c','listen_addresses=127.0.0.1','-c','unix_socket_directories='],
  onLog:()=>{}, onError:error=>console.error(String(error))
});
let app;
let started = false;
try {
  if (!existsSync(join(cluster,'PG_VERSION'))) await database.initialise();
  await database.start();
  started = true;
  const connection = `postgresql://sgu:${password}@127.0.0.1:${port}`;
  const client = new pg.Client({connectionString:connection+'/postgres'});
  await client.connect();
  try {
    const {rowCount}=await client.query("SELECT 1 FROM pg_database WHERE datname='sgu'");
    if (!rowCount) await client.query('CREATE DATABASE sgu');
  } finally {
    await client.end();
  }
  app = spawn(process.execPath, [fileURLToPath(new URL('./server.mjs',import.meta.url))], {
    cwd:new URL('.',import.meta.url), env:{...process.env,DATABASE_URL:connection+'/sgu',PORT:'8080',HOST:'127.0.0.1'}, stdio:'inherit'
  });
  const finished = once(app,'exit');
  for (const signal of ['SIGINT','SIGTERM']) process.once(signal,()=>app.kill());
  const url='http://127.0.0.1:8080/';
  for (let attempt=0; attempt<40 && app.exitCode===null; attempt++) {
    const response=await fetch(url,{signal:AbortSignal.timeout(1200)}).catch(()=>null);
    if (response?.ok && (await response.text()).includes('<h1>Entrar no SGU</h1>')) {
      console.log('SGU em '+url+' — mantenha esta janela aberta.');
      if (isWindows) spawn('cmd.exe',['/d','/c','start','','http://127.0.0.1:8080/'],{stdio:'ignore'}).unref();
      break;
    }
    await new Promise(resolve=>setTimeout(resolve,400));
  }
  const [code]=await finished;
  process.exitCode=code??0;
} finally {
  if(app?.exitCode===null) app.kill();
  if(started) await database.stop();
}
