@echo off
setlocal
cd /d "%~dp0"
where docker >nul 2>&1
if errorlevel 1 goto no_docker
docker info >nul 2>&1
if errorlevel 1 goto docker_stopped
if not exist ".env" (
  powershell -NoProfile -Command "$b = New-Object byte[] 32; $rng = [Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($b); $rng.Dispose(); $p = [BitConverter]::ToString($b).Replace('-','').ToLowerInvariant(); [IO.File]::WriteAllText((Join-Path (Get-Location).Path '.env'), ('POSTGRES_PASSWORD=' + $p + [Environment]::NewLine))"
  if errorlevel 1 goto failed
)
docker compose up -d --build
if errorlevel 1 goto failed
powershell -NoProfile -Command "for ($i=0; $i -lt 30; $i++) { try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:8080/'; if ($r.Content -match '<h1>Entrar no SGU</h1>') { exit 0 } } catch {}; Start-Sleep -Seconds 2 }; exit 1"
if errorlevel 1 goto failed
start "" "http://127.0.0.1:8080/"
exit /b 0
:no_docker
echo Instale o Docker Desktop e execute este arquivo novamente.
goto error
:docker_stopped
echo Abra o Docker Desktop e aguarde o motor iniciar. Depois execute este arquivo novamente.
goto error
:failed
docker compose ps
docker compose logs --tail=30 app db
:error
pause
exit /b 1
