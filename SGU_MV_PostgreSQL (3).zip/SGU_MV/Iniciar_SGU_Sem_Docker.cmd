@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 goto node_missing
node -e "if (Number(process.versions.node.split('.')[0]) < 22) process.exit(1)"
if errorlevel 1 goto node_missing
node -e "if (process.arch !== 'x64') process.exit(1)"
if errorlevel 1 goto architecture
call npm ci --omit=dev --no-audit --no-fund
if errorlevel 1 goto failed
node iniciar-local.mjs
if errorlevel 1 goto failed
exit /b 0
:node_missing
echo Instale o Node.js LTS e abra novamente este arquivo.
echo https://nodejs.org/pt-br/download
goto error
:architecture
echo Este pacote de PostgreSQL para Windows requer Node.js x64.
goto error
:failed
echo O SGU nao iniciou. Confira as mensagens acima.
:error
pause
exit /b 1
