import { randomBytes } from 'node:crypto';
import { writeFileSync } from 'node:fs';

const dbPassword = randomBytes(32).toString('hex');
try {
  writeFileSync('.env', `POSTGRES_PASSWORD=${dbPassword}\n`, {flag:'wx', mode:0o600});
  console.log('Configuração local criada em .env.');
} catch (error) {
  if (error.code !== 'EEXIST') throw error;
  console.log('Configuração local existente preservada.');
}
